^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package joystick_drivers
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

1.12.0 (2018-06-11)
-------------------
* Addressed numerous outstanding PRs.
* Changed package xml to format 2
* Contributors: Jonathan Bohren, jprod123

1.11.0 (2017-02-10)
-------------------

1.10.1 (2015-05-24)
-------------------

1.10.0 (2014-06-26)
-------------------
* First indigo release

#pragma once

namespace racecar_simulator {

struct Pose2D {
    double x;
    double y;
    double theta;
};

}

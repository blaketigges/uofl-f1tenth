
"use strict";

let RaceInfo = require('./RaceInfo.js');

module.exports = {
  RaceInfo: RaceInfo,
};
